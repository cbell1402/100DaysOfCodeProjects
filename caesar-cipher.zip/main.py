import art


def caesar(plain_text, shift_amount, choice):
  text_list = list(plain_text)
  idx = 0
  if choice == "decode":
    shift_amount *= -1
  for i in text_list:
    for j in alphabet:
      if i == j:
        hold = alphabet.index(i) + shift_amount
        text_list[idx] = alphabet[hold % len(alphabet)]
        break
    idx += 1
  new_text = ''.join(text_list)
  print(f"The {choice}d text is: {new_text}")

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
print(art.logo)

keep_going = True
while keep_going:
  direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
  text = input("Type your message:\n").lower()
  shift = int(input("Type the shift number:\n"))
  
  caesar(plain_text=text, shift_amount=shift, choice=direction)

  quit = input("\nDo you want to use the cipher again? yes/no: ").lower()
  if quit == "no":
    keep_going = False
    print("Goodbye!")
    