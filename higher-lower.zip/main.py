import replit
import random as rn
import art
import game_data as gd

score = 0
game_over = False

while game_over != True:
    print(art.logo)
    
    if score > 0:
        print(f"Right! Current score is: {score}")
    
    if score == 0:
        person1 = rn.choice(gd.data)
        person2 = rn.choice(gd.data)
    else:
        person1 = person2
        person2 = rn.choice(gd.data)
    
    while person1 == person2:
        person2 = rn.choice(gd.data)
    
    #person1 , person2 = person_selector(score)
    followers1 = person1['follower_count']
    followers2 = person2['follower_count']

    print(f"Compare A: {person1['name']}, a {person1['description']}, from {person1['country']}.")
    print(art.vs)
    print(f"Compare B: {person2['name']}, a {person2['description']}, from {person2['country']}.")

    choice = input("Who has more followers? A or B: ").lower()

    if choice == "a" and followers1 >= followers2:
        score += 1
        replit.clear()
    elif choice == "b" and followers1 <= followers2:
        score += 1
        replit.clear()
    else:
        replit.clear()
        print(f"That is wrong. Final score: {score}")
        game_over = True