from replit import clear
import art
#HINT: You can call clear() to clear the output in the console.
print(art.logo)

bidder_dict = {}
print("Welcome to the secret auction program.")
keep_going = True
while keep_going:
    name = input("What is your name?: ")
    bid = int(input("What is your bid?: $"))
    again = input("Are they any other bidders? yes/no: ").lower()
    clear()
    bidder_dict[name] = bid
    if again == "no":
        keep_going = False

#print(bidder_dict)
high_bid = 0
for keys in bidder_dict:
    if bidder_dict[keys] > high_bid:
        high_bid = bidder_dict[keys]
        high_bidder = keys

print(f"The winner is {high_bidder}, with a bid of ${high_bid}.")