import art


def add(n1, n2):
    return n1 + n2

def subtract(n1, n2):
    return n1 - n2

def multiply(n1, n2):
    return n1 * n2

def divide(n1, n2):
    return n1 / n2

operation_dict = {
    "+":add, 
    "-":subtract, 
    "*":multiply, 
    "/":divide,
}
def calculator():
    print(art.logo)
    num1 = float(input("What is the first number?: "))

    print("The available operations are as follows:")
    for keys in operation_dict:
        print(keys)

    keep_going = True
    while keep_going:
        operation = input("Which operation do you want?: ")
        num2 = float(input("What is the next number?: "))
        
        answer = operation_dict[operation](num1, num2)
        print(f"{num1} {operation} {num2} = {answer}")
        num1 = answer
        if input(f"Type 'y' to continue with {num1}, or 'n' to start a new calculation: ").lower() != "y":
            keep_going = False
            calculator()
    
calculator()