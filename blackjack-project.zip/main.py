############### Blackjack Project #####################

import art
import random as rn
import replit

def compare(p_sum, c_sum):
    """Compares the player's and computer's scores"""
    if p_sum > c_sum:
        return "win"
    elif p_sum < c_sum and c_sum <= 21:
        return "lose"
    elif p_sum == c_sum:
        return "draw"

def blackjack(wins, games):
    """Plays the game of Blackjack"""
    print(art.logo)
    games += 1
    player_hand = [rn.choice(cards), rn.choice(cards)]
    player_sum = sum(player_hand)
    comp_hand = [rn.choice(cards), rn.choice(cards)]
    comp_sum = sum(comp_hand)
    
    print(f"    Your cards: {player_hand}, score: {player_sum}")
    print(f"    Computer's first card: {comp_hand[0]}")

    #Checks for a player Blackjack
    if player_sum == 21:
        print(f"    Your final hand: {player_hand}, score: {player_sum}")
        print(f"    Computer's final hand: {comp_hand}, score: {comp_sum}")
        print("Win with a Blackjack!")
        wins += 1
        play = input("Do you want to play a game of Blackjack? y/n: ").lower()
        if play == "y":
            replit.clear()
            blackjack(wins, games)
        else:
            print(f"You won {wins} out of {games} games.")
            return

    stop = False
    #Allows the player to hit
    while(player_sum <= 21 and stop == False):
        hit = input("Type 'y' to hit or 'n' to stand: ").lower()
        if hit == "y":
            player_hand.append(rn.choice(cards))
            player_sum = sum(player_hand)
            if player_sum > 21:
                for n, i in enumerate(player_hand):
                    if i == 11:
                        player_hand[n] = 1
                        print("You would have went over with an ace, so it is now equal to 1.")
                        player_sum = sum(player_hand)            
            print(f"    Your cards: {player_hand}, score: {player_sum}")
        else:
            stop = True
    
    #Checks for a computer Blackjack
    if comp_sum == 21:
        print(f"    Your final hand: {player_hand}, score: {player_sum}")
        print(f"    Computer's final hand: {comp_hand}, score: {comp_sum}")
        print("Computer has a blackjack, you lose.")
        wins += 1
        play = input("Do you want to play a game of Blackjack? y/n: ").lower()
        if play == "y":
            replit.clear()
            blackjack(wins, games)
        else:
            print(f"You won {wins} out of {games} games.")
            return

    #Computer must have a score of 17 or greater
    while comp_sum < 17:
        comp_hand.append(rn.choice(cards))
        comp_sum = sum(comp_hand)
    print(f"    Your final hand: {player_hand}, score: {player_sum}")
    print(f"    Computer's final hand: {comp_hand}, score: {comp_sum}")

    #Looks for win/lose conditions
    condition = compare(player_sum, comp_sum)
    if player_sum > 21:
        print("Bust! You lose.")
    elif comp_sum > 21:
        print("Computer bust! You win!")
        wins += 1
    elif condition == "win":
        print("You win!")
        wins += 1
    elif condition == "lose":
        print("You lose.")
    elif condition == "draw":
        print("Draw!")
            
    #Allows the player to play again
    if input("Do you want to play another game of Blackjack? y/n: ").lower() == "y":
        replit.clear()
        blackjack(wins, games)
    else:
        print(f"You won {wins} out of {games} games.")
        return



cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
play = input("Do you want to play a game of Blackjack? y/n: ").lower()
wins = 0
games = 0
if play == "y":
    blackjack(wins, games)