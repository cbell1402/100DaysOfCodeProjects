import random as rn 
import art

def guesser(rand_num, num_trys):
    '''Runs the guesser'''
    keep_going = True
    while num_trys > 0 and keep_going == True:
        print(f"You have {num_trys} guesses left.")
        guess = int(input("Make a guess: "))
        if guess == rand_num:
            print(f"You got it! The number was {rand_num}.")
            keep_going = False
            return
        elif guess > rand_num:
            print("Too high.")
        elif guess < rand_num:
            print("Too low.")
        num_trys -= 1
    print("You've run out of guesses. You lose.")

def difficulty_selector():
    '''Allowes user to select difficulty'''
    difficulty = input("Choose a difficulty. Easy/Hard: ").lower()

    if difficulty == "easy":
        trys = 10
    elif difficulty == "hard":
        trys = 5
    return(trys)

print(art.logo)
print("Welcome to the Number Guessing Game!")
print("I'm thinking of a number between 1 and 100.")

guesser(rn.randint(1,100), difficulty_selector())